library IEEE;
use IEEE.Std_logic_1164.all;
use IEEE.Numeric_Std.all;

entity ALU_tb is
end;

architecture bench of ALU_tb is

  component ALU
      Port ( A : in STD_LOGIC_VECTOR (7 downto 0);
             B : in STD_LOGIC_VECTOR (7 downto 0);
             Cin : in STD_LOGIC;
             F : out STD_LOGIC_VECTOR (7 downto 0);
             SET : in STD_LOGIC_VECTOR (3 downto 0));
  end component;

  signal A: STD_LOGIC_VECTOR (7 downto 0);
  signal B: STD_LOGIC_VECTOR (7 downto 0);
  signal Cin: STD_LOGIC;
  signal F: STD_LOGIC_VECTOR (7 downto 0);
  signal SET: STD_LOGIC_VECTOR (3 downto 0);

begin

  uut: ALU port map ( A   => A,
                      B   => B,
                      Cin => Cin,
                      F   => F,
                      SET => SET );

  stimulus: process
  begin
  
    -- Put initialisation code here
    A <= "00100001";
    B <= "00111011";
    SET <= "0000";
    Cin <= '0';
    wait for 10ns;
    Cin <= '1';
    wait for 10ns;
    SET <= "0001";
    Cin <= '0';
    wait for 10ns;
    Cin <= '1';
    wait for 10ns;
    SET <= "0010";
    Cin <= '0';
    wait for 10ns;
    Cin <= '1';
    wait for 10ns;
    SET <= "0011";
    Cin <= '1';
    wait for 10ns;
    SET <= "0100";
    wait for 10ns;
    SET <= "0101";
    wait for 10ns;   
    SET <= "0110";
    wait for 10ns;
    SET <= "0111";
    wait for 10ns;
    SET <= "1001";
    wait for 10ns;
    SET <= "1101";
    wait for 10ns;
    SET <= (others => 'Z');
    -- Put test bench stimulus code here

    wait;
  end process;


end;