
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
use IEEE.NUMERIC_STD.ALL;

-- Uncomment the following library declaration if instantiating
-- any Xilinx leaf cells in this code.
--library UNISIM;
--use UNISIM.VComponents.all;

entity ALU is
    Port ( A : in STD_LOGIC_VECTOR (7 downto 0);
           B : in STD_LOGIC_VECTOR (7 downto 0);
           Cin : in STD_LOGIC;
           F : out STD_LOGIC_VECTOR (7 downto 0);
           SET : in STD_LOGIC_VECTOR (3 downto 0));
end ALU;

architecture Behavioral of ALU is
signal trans : std_logic_vector(7 downto 0);
signal incrementA : signed (7 downto 0);
signal ADD : signed (7 downto 0);
signal ADDCIN : signed(7 downto 0);
signal Bminos : signed(7 downto 0);
signal bminosinc : signed(7 downto 0);
signal dencrement : signed(7 downto 0);
signal AND_F : std_logic_vector(7 downto 0);
signal OR_F : std_logic_vector(7 downto 0);
signal XOR_F : std_logic_vector(7 downto 0);
signal NOT_F : std_logic_vector(7 downto 0);
signal SHR_F : unsigned(7 downto 0);
signal SHL_F : unsigned(7 downto 0);

begin
trans <= A;
incrementA <= signed(A) + 1;
ADD <= signed(A) + signed(B);
ADDCIN <= ADD + 1;--                                                remember to change it 
Bminos <= signed(A) - signed(B);
bminosinc <= Bminos + 1;--                                             remember to change it 
dencrement <= signed(A) - 1;
AND_F <= A and B;
OR_F <= A or B;
XOR_F <= A xor B;
NOT_F <= not (A);
SHR_F <= shift_right(unsigned(A),1);
SHL_F <= shift_left(unsigned(A),1);

F <= trans when SET ="0000" and Cin ='0' else
std_logic_vector(incrementA) when SET ="0000" and Cin ='1' else 
std_logic_vector(ADD)        when SET ="0001" and Cin ='0' else 
std_logic_vector(ADDCIN)     when SET ="0001" and Cin ='1' else 
std_logic_vector(Bminos)     when SET ="0010" and Cin ='0' else   
std_logic_vector(bminosinc)  when SET ="0010" and Cin ='1' else 
std_logic_vector(dencrement) when SET ="0011" and Cin ='1' else 
std_logic_vector(AND_F)      when SET ="0100"              else   
std_logic_vector(OR_F)       when SET ="0101"              else
std_logic_vector(XOR_F)      when SET ="0110"              else
std_logic_vector(NOT_F)      when SET ="0111"              else   
std_logic_vector(SHR_F)      when SET(3)='1' and SET(2)='0' else
std_logic_vector(SHL_F)      when SET(3)='1' and SET(2)='1' else
(others => 'Z');


end Behavioral;
