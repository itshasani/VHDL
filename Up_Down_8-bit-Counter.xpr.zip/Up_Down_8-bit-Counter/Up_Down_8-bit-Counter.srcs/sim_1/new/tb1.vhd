library IEEE;
use IEEE.Std_logic_1164.all;
use IEEE.Numeric_Std.all;

entity Counter_tb is
end;

architecture bench of Counter_tb is

  component Counter
      Port ( Pre_Load_Count : in STD_LOGIC_VECTOR (7 downto 0);
             Up_Down : in STD_LOGIC;
             Pre_Load_En : in STD_LOGIC;                          
             Pre_Reset_En : in STD_LOGIC;
             Reset : in STD_LOGIC;
             Clk : in STD_LOGIC;
             Count : out STD_LOGIC_VECTOR (7 downto 0);
             Interrupt : out STD_LOGIC);
  end component;

  signal Pre_Load_Count: STD_LOGIC_VECTOR (7 downto 0);
  signal Up_Down: STD_LOGIC;
  signal Pre_Load_En: STD_LOGIC;
  signal Pre_Reset_En: STD_LOGIC;
  signal Reset: STD_LOGIC;
  signal Clk: STD_LOGIC;
  signal Count: STD_LOGIC_VECTOR (7 downto 0);
  signal Interrupt: STD_LOGIC;

  constant clock_period: time := 5 ns;
  signal stop_the_clock: boolean;

begin

  uut: Counter port map ( Pre_Load_Count => Pre_Load_Count,
                          Up_Down        => Up_Down,
                          Pre_Load_En    => Pre_Load_En,
                          Pre_Reset_En   => Pre_Reset_En,
                          Reset          => Reset,
                          Clk            => Clk,
                          Count          => Count,
                          Interrupt      => Interrupt );

  stimulus: process
  begin
  
    -- Put initialisation code here

    

    -- Put test bench stimulus code here


    Pre_Load_Count <= "01010101";
    Up_Down <= '1';
    Pre_Load_En <= '1';
    Pre_Reset_En <= '0';
    Reset <= '0';
    wait for 1.5 us;
    Reset <= '1';
    wait for 10ns;
    
    
    
    
    
    
    Up_Down <= '1';
    Pre_Load_En <= '0';
    Pre_Reset_En <= '1';
    Reset <= '0';    
    wait for 1.5 us;
    Reset <= '1';
    wait for 10ns;
    
    
    Up_Down <= '0';
    Pre_Load_En <= '1';
    Pre_Reset_En <= '0';
    Reset <= '0';    
    wait for 1.5 us;
    Reset <= '1';
    wait for 10ns;    
    
     Up_Down <= '0';
    Pre_Load_En <= '0';
    Pre_Reset_En <= '1';
    Reset <= '0';    

    
    
    
    
    
    wait;
  end process;

  clocking: process
  begin
    while not stop_the_clock loop
      Clk <= '0', '1' after clock_period / 2;
      wait for clock_period;
    end loop;
    wait;
  end process;

end;
  