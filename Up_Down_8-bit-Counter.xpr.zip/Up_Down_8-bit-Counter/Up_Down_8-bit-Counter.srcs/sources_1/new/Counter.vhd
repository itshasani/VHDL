
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;

-- Uncomment the following library declaration if instantiating
-- any Xilinx leaf cells in this code.
--library UNISIM;
--use UNISIM.VComponents.all;

entity Counter is
    Port ( Pre_Load_Count : in STD_LOGIC_VECTOR (7 downto 0); -- with this number we can load the counter
           Up_Down : in STD_LOGIC;                              -- 1 is for Up 
           Pre_Load_En : in STD_LOGIC;                          
           Pre_Reset_En : in STD_LOGIC;
           Reset : in STD_LOGIC;
           Clk : in STD_LOGIC;
           Count : out STD_LOGIC_VECTOR (7 downto 0);                   -- the output for counter
           Interrupt : out STD_LOGIC);                                    -- after finishing the counting it will be '1'
end Counter;

architecture Behavioral of Counter is
signal intrpt : std_logic := '0';


begin

process(Clk,Pre_Load_Count,Up_Down,Pre_Load_En,Pre_Reset_En,Reset,intrpt)
variable Counter : integer := 0;
begin 
    if (Reset = '0') then 
        if (rising_edge(Clk) and intrpt = '0') then 
            if (Up_Down = '1')  then -- Counting Upwards
                if(Pre_Load_En = '1' and Pre_Reset_En = '0') then     -- Counting with preLoad
                    if (Counter = 0) then 
                        Counter := to_integer(unsigned(Pre_Load_Count));
                    else         
                        Counter := Counter + 1;
                        if (Counter = 255) then 
                            intrpt <= '1';
                        end if;
                    end if;
                elsif (Pre_Load_En = '0' and Pre_Reset_En = '1') then -- Counting with PreReset
                     Counter := Counter + 1;
                     if(Counter = to_integer(unsigned(Pre_Load_Count))) then 
                        intrpt <= '1';
                     end if;
                end if;
            else                      -- Counting Downwards
                if(Pre_Load_En = '1' and Pre_Reset_En = '0') then    -- Counting with preLoad
                    if (Counter = 0) then 
                        Counter := to_integer(unsigned(Pre_Load_Count));
                    else         
                        Counter := Counter - 1;
                        if (Counter = 0) then 
                            intrpt <= '1';
                        end if;
                    end if;   
                
                elsif (Pre_Load_En = '0' and Pre_Reset_En = '1') then -- Counting with PreReset
                    if (Counter = 0) then 
                        Counter := 255 ;
                    else         
                        Counter := Counter - 1;
                        if(Counter = to_integer(unsigned(Pre_Load_Count))) then 
                             intrpt <= '1';
                        end if;
                    end if;
                end if;
            end if;
        end if;
    else -- the counter must start from  its initials (preload or 0)
        intrpt <= '0';
        Counter := 0;
        
    end if;
    Count <= std_logic_vector(to_unsigned(Counter,8));
    Interrupt <= intrpt;
end process;

end Behavioral;
