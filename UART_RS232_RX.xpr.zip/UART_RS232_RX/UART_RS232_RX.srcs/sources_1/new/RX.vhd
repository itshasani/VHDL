
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
use IEEE.NUMERIC_STD.ALL;

-- Uncomment the following library declaration if instantiating
-- any Xilinx leaf cells in this code.
--library UNISIM;
--use UNISIM.VComponents.all;

entity RX is
    Port ( Din : in STD_LOGIC;
           Clk : in STD_LOGIC;                         -- 100 MHZ clock
           Dout : out STD_LOGIC_VECTOR (7 downto 0);    -- the boud rate is 115200 bit /sec so we need 858 100Mhz clock cycles
           Valid : out STD_LOGIC
            );
end RX;

architecture Behavioral of RX is
type states is (idle,start,bit0,bit1,bit2,bit3,bit4,bit5,bit6,bit7,parity_x,stop);
signal pr_state : states := idle;
signal din_reg : std_logic;
signal parity_reg : std_logic;
signal parity_out : std_logic;
signal Data_reg : std_logic_vector(7 downto 0);
signal rx_data : std_logic;
signal Valid_reg : std_logic;
constant baudRate_count : integer := 868;
begin 

process(clk)
begin 
    if rising_edge(Clk) then 
         din_reg <= Din;
         rx_data <= din_reg;
    end if;
end process;
process(clk)
variable counter : integer := 0;
begin 
    if rising_edge(clk) then 
        case pr_state is 
                    when idle =>
                if rx_data = '0' then 
                    counter := counter + 1;
                    if counter = baudRate_count then 
                        pr_state <= start;
                        counter := 0;
                    else 
                        pr_state <= idle; 
                    end if;
                else 
                    pr_state <= idle; 
                end if;
                    when start =>
                counter := counter + 1;
                if counter = baudRate_count/2 then 
                    Data_reg(0) <= rx_data;
                elsif counter = baudRate_count then 
                       pr_state <= bit0;
                       counter := 0;
                else 
                    pr_state <= start;
                end if;
                     when bit0 =>
                counter := counter + 1;
                if counter = baudRate_count/2 then 
                    Data_reg(1) <= rx_data;
                elsif counter = baudRate_count then 
                       pr_state <= bit1;
                       counter := 0;
                else 
                    pr_state <= bit0;
                end if; 
                     when bit1 =>
                counter := counter + 1;
                if counter = baudRate_count/2 then 
                    Data_reg(2) <= rx_data;
                elsif counter = baudRate_count then 
                       pr_state <= bit2;
                       counter := 0;
                else 
                    pr_state <= bit1;
                end if;     
                 when bit2 =>
                counter := counter + 1;
                if counter = baudRate_count/2 then 
                    Data_reg(3) <= rx_data;
                elsif counter = baudRate_count then 
                       pr_state <= bit3;
                       counter := 0;
                else 
                    pr_state <= bit2;
                end if; 
                 when bit3 =>
                counter := counter + 1;
                if counter = baudRate_count/2 then 
                    Data_reg(4) <= rx_data;
                elsif counter = baudRate_count then 
                       pr_state <= bit4;
                       counter := 0;
                else 
                    pr_state <= bit3;
                end if;    
                 when bit4 =>
                counter := counter + 1;
                if counter = baudRate_count/2 then 
                    Data_reg(5) <= rx_data;
                elsif counter = baudRate_count then 
                       pr_state <= bit5;
                       counter := 0;
                else 
                    pr_state <= bit4;
                end if;    
                 when bit5 =>
                counter := counter + 1;
                if counter = baudRate_count/2 then 
                    Data_reg(6) <= rx_data;
                elsif counter = baudRate_count then 
                       pr_state <= bit6;
                       counter := 0;
                else 
                    pr_state <= bit5;
                end if;    
                  when bit6 =>
                counter := counter + 1;
                if counter = baudRate_count/2 then 
                    Data_reg(7) <= rx_data;
                elsif counter = baudRate_count then 
                       pr_state <= bit7;
                       counter := 0;
                else 
                    pr_state <= bit6;
                end if;   
                   when bit7 =>
                counter := counter + 1;
                if counter = baudRate_count/2 then 
                    parity_reg <= rx_data;
                    parity_out <=  Data_reg(7) xor Data_reg(6) xor Data_reg(5) xor Data_reg(4) xor Data_reg(3) xor Data_reg(2) xor Data_reg(1) xor Data_reg(0);
                    
                elsif counter = baudRate_count then 
                       pr_state <= parity_x;
                       counter := 0;
                else 
                    pr_state <= bit7;
                end if;  
                    when parity_x =>
                counter := counter + 1;
                if counter = baudRate_count/2 then 
                       if  parity_out = parity_reg then 
                            Valid_reg <= '1';
                       else 
                            Valid_reg <= '0';
                       end if;
                elsif counter = baudRate_count then 
                       pr_state <= stop;
                       counter := 0;
                else 
                    pr_state <= parity_x;
                end if;   
                    when stop =>
                         counter := counter + 1;     
                         if counter = baudRate_count/2 then 
                            if rx_data = '1' then 
                                Valid <= Valid_reg;
                            else 
                                 Valid <= '0';
                            end if;
                         elsif counter = baudRate_count then 
                            pr_state <= idle;
                             counter := 0;
                         else 
                            pr_state <= stop;
                         end if;
                               
          end case;
          Dout <= Data_reg;                                                                                                  
    end if;
end process;
end Behavioral;
