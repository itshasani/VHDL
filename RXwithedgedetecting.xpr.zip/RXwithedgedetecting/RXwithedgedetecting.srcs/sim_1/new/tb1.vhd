LIBRARY ieee;
USE ieee.std_logic_1164.ALL;
 
-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
USE ieee.numeric_std.ALL;
 
ENTITY tb1 IS
END tb1;
 
ARCHITECTURE behavior OF tb1 IS 
 
    -- Component Declaration for the Unit Under Test (UUT)
 
    COMPONENT RX
    Port ( Din : in STD_LOGIC;
           Clk : in STD_LOGIC;                         -- 100 MHZ clock
           Dout : out STD_LOGIC_VECTOR (7 downto 0);    -- the boud rate is 115200 bit /sec so we need 858 100Mhz clock cycles
           Valid : out STD_LOGIC
            );
    END COMPONENT;
    

   --Inputs
   signal Din : std_logic := '0';
   signal Clk : std_logic := '0';
 	--Outputs
   signal Dout : std_logic_vector(7 downto 0);
   signal Valid : std_logic;
   -- Clock period definitions
   constant Clk_period : time := 10 ns;
 
BEGIN
 
	-- Instantiate the Unit Under Test (UUT)
   uut: RX PORT MAP (
          Din => Din,
          Clk => Clk,
          Dout => Dout,
          Valid => Valid
          
        );

   -- Clock process definitions
   Clk_process :process
   begin
		Clk <= '0';
		wait for Clk_period/2;
		Clk <= '1';
		wait for Clk_period/2;
   end process;
 

   -- Stimulus process
   stim_proc: process
   begin		
      -- hold reset state for 100 ns.
        Din <= '1';
		wait for 10us;
		wait for 8.68us;
		wait for 8.68ns;
		Din <= '0';       -- start bit
		wait for 8.68us;
		Din <= '1';       --bit0
		wait for 8.68us;
		Din <= '0';       --bit1
		wait for 8.68us;
		Din <= '1';       --bit2
		wait for 8.68us;
		Din <= '1';       --bit3
		wait for 8.68us;
		Din <= '0';       
		wait for 8.68us;
		Din <= '0';       --bit5
		wait for 8.68us;
		Din <= '1';       --bit6
		wait for 8.68us;
		Din <= '1';       --bit7
		wait for 8.68us;
		Din <= '1';       -- parity
		wait for 8.68us;
	    Din <= '1';
  		
		
      wait;
   end process;

END;
