
LIBRARY ieee;
USE ieee.std_logic_1164.ALL;
 
-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
USE ieee.numeric_std.ALL;
 
ENTITY tb2 IS
END tb2;
 
ARCHITECTURE behavior OF tb2 IS 
 
    -- Component Declaration for the Unit Under Test (UUT)
 
    COMPONENT TXplusRX
    Port ( Clock : in STD_LOGIC;
           DataIn : in STD_LOGIC_VECTOR (7 downto 0);
           DataOut : out STD_LOGIC_VECTOR (7 downto 0);
           EN : in STD_LOGIC;
           VALID : out STD_LOGIC;
           BUSY : out STD_LOGIC);
    END COMPONENT;
    

   --Inputs
   signal EN : std_logic := '0';
   signal Clock : std_logic := '0';
   signal BUSY : std_logic := '0';
   
 	--Outputs
   signal DataIn : std_logic_vector(7 downto 0);
   signal DataOut : std_logic_vector(7 downto 0);
   signal VALID : std_logic;
   -- Clock period definitions
   constant Clk_period : time := 10 ns;
 
BEGIN
 
	-- Instantiate the Unit Under Test (UUT)
   uut: TXplusRX PORT MAP (
          Clock => Clock,
          DataIn => DataIn,
          DataOut => DataOut,
          EN => EN,
          BUSY => BUSY,
          VALID => VALID
        );

   -- Clock process definitions
   Clk_process :process
   begin
		Clock <= '0';
		wait for Clk_period/2;
		Clock <= '1';
		wait for Clk_period/2;
   end process;
 

   -- Stimulus process
   stim_proc: process
   begin		
      -- hold reset state for 100 ns.
        DataIn <= "01101100";
        En <= '0';
        wait for 10ns;
        En <= '1';
      -- insert stimulus here 

      wait;
   end process;

END;
