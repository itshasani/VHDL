
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
use IEEE.NUMERIC_STD.ALL;

-- Uncomment the following library declaration if instantiating
-- any Xilinx leaf cells in this code.
--library UNISIM;
--use UNISIM.VComponents.all;

entity TX is
    Port ( Din : in STD_LOGIC_VECTOR (7 downto 0); -- imagine the Baud Rate is : 115200; so we need 868 * 10 ns 
           En : in STD_LOGIC;
           Clk : in STD_LOGIC;                     -- 100MHZ
           Dout : out STD_LOGIC;
           Busy : out STD_LOGIC);
end TX;

architecture Behavioral of TX is
signal clk_115200HZ : std_logic:='0';
signal counter : integer := 1;
type states is (idle,start,bit0,bit1,bit2,bit3,bit4,bit5,bit6,bit7,parity,stop);
signal nx_state,pr_state : states := idle;
signal Busy_reg : std_logic := '0';
begin
CLOCK : process(Clk)
        begin 
            if rising_edge(Clk) then 
               counter <= counter + 1;
                if counter = 434 then 
                    counter <= 0;
                    clk_115200HZ <= not clk_115200HZ;
                end if;    
            end if;
end process;
process(clk_115200HZ,En)
begin 
    if rising_edge(clk_115200HZ) then 
        if En ='1' then 
            pr_state <= nx_state;
        else 
            pr_state <= idle;
            Busy_reg <= '0';
        end if;
    end if;
end process;
process(pr_state)
begin
    case pr_state is
        when idle =>
               if(Busy_reg = '0') then 
                    nx_state <= start;
               end if;
               Dout <= '1';
               Busy <= '0';
         when start =>
                Dout <= '0';
                nx_state <= bit0;
                Busy <= '1';
         when bit0  =>
                Dout <= Din(0);
                nx_state <= bit1;
                Busy <= '1';
         when bit1 =>
                Dout <= Din(1);
                nx_state <= bit2;
                Busy <= '1';
         when bit2  =>
                Dout <= Din(2);
                nx_state <= bit3;
                Busy <= '1';
         when bit3  =>
                Dout <= Din(3);
                nx_state <= bit4;
                Busy <= '1';              
         when bit4  =>
                Dout <= Din(4);
                nx_state <= bit5;  
                Busy <= '1';
         when bit5  =>
                Dout <= Din(5);
                nx_state <= bit6;
                Busy <= '1'; 
         when bit6  =>
                Dout <= Din(6);
                nx_state <= bit7;
                Busy <= '1';    
         when bit7  =>
                Dout <= Din(7);
                nx_state <= parity;
                Busy <= '1';
         when parity =>
                Dout <= Din(0) xor Din(1) xor Din(2) xor Din(3) xor Din(4) xor Din(5) xor Din(6) xor Din(7);
                nx_state <= stop;
                Busy <= '1';                
         when stop =>
                Dout <= '1';
                Busy <= '1';
                nx_state <= idle;
                Busy_reg <= '1';
        end case;                                                                      
end process;
end Behavioral;
