library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
use IEEE.NUMERIC_STD.ALL;

-- Uncomment the following library declaration if instantiating
-- any Xilinx leaf cells in this code.
--library UNISIM;
--use UNISIM.VComponents.all;

entity TXplusRX is
    Port ( Clock : in STD_LOGIC;
           DataIn : in STD_LOGIC_VECTOR (7 downto 0);
           DataOut : out STD_LOGIC_VECTOR (7 downto 0);
           EN : in STD_LOGIC;
           VALID : out STD_LOGIC;
           BUSY : out STD_LOGIC);
end TXplusRX;

architecture Behavioral of TXplusRX is
        component RX
    Port ( Din : in STD_LOGIC;
           Clk : in STD_LOGIC;
           Dout : out STD_LOGIC_VECTOR (7 downto 0);
           Valid : out STD_LOGIC
            );
        end component;
        component TX
    Port ( Din : in STD_LOGIC_VECTOR (7 downto 0); -- imagine the Baud Rate is : 115200;
           En : in STD_LOGIC;
           Clk : in STD_LOGIC;                     -- 100MHZ
           Dout : out STD_LOGIC;
           Busy : out STD_LOGIC
           );
         end component;
     signal interface : std_logic;        
begin
    Inst_RX : RX port map(
        Clk => Clock,
        Din => interface,
        Valid => VALID,
        Dout => DataOut
        );
     Inst_TX : TX port map(
        Din => DataIn,
        Dout => interface,
        Clk => Clock,
        En => EN,
        Busy => BUSY
        );

end Behavioral;
