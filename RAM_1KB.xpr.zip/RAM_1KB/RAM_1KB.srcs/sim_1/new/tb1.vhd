
library IEEE;
use IEEE.Std_logic_1164.all;
use IEEE.Numeric_Std.all;

entity RAM_tb is
end;

architecture bench of RAM_tb is

  component RAM
      Port ( Add : in STD_LOGIC_VECTOR (9 downto 0);
             Din : in STD_LOGIC_VECTOR (7 downto 0);
             WR : in STD_LOGIC;
             Dout : out STD_LOGIC_VECTOR (7 downto 0));
  end component;

  signal Add: STD_LOGIC_VECTOR (9 downto 0);
  signal Din: STD_LOGIC_VECTOR (7 downto 0);
  signal WR: STD_LOGIC;
  signal Dout: STD_LOGIC_VECTOR (7 downto 0);

begin

  uut: RAM port map ( Add  => Add,
                      Din  => Din,
                      WR   => WR,
                      Dout => Dout );

  stimulus: process
  begin
  
    -- Put initialisation code here
    WR <= '1';
    Din <= "00000011";
    ADD <= "0000000000";
    wait for 10ns;
    Din <= "01000000";
    ADD <= "0000000001";
    wait for 10ns;
    Din <= "00001001";
    ADD <= "0000000010";
    wait for 10ns;
    Din <= "00110000";
    ADD <= "0000000011";
    wait for 10ns;
    Din <= "01111110";
    ADD <= "0000000100";    
    wait for 10ns;
    WR <= '0';
    ADD <= "0000000000";
    wait for 10ns;
    ADD <= "0000000001";
    wait for 10ns;
    ADD <= "0000000010";
    wait for 10ns;
    ADD <= "0000000011";
    wait for 10ns;
    ADD <= "0000000100";

    
    -- Put test bench stimulus code here

    wait;
  end process;


end;