

library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
use IEEE.NUMERIC_STD.ALL;

-- Uncomment the following library declaration if instantiating
-- any Xilinx leaf cells in this code.
--library UNISIM;
--use UNISIM.VComponents.all;

entity RAM is
    Port ( Add : in STD_LOGIC_VECTOR (9 downto 0);
           Din : in STD_LOGIC_VECTOR (7 downto 0);
           WR : in STD_LOGIC;
           Dout : out STD_LOGIC_VECTOR (7 downto 0));
end RAM;

architecture Behavioral of RAM is
type RAM is array (0 to 1023) of std_logic_vector(7 downto 0);
signal RAM_1KB : RAM;
begin
process(WR,Din,Add)

begin 
if (WR = '1') then 
   RAM_1KB(to_integer(unsigned(ADD))) <= Din;  
else 
    Dout <= RAM_1KB(to_integer(unsigned(ADD)));
end if;

end process;

end Behavioral;
