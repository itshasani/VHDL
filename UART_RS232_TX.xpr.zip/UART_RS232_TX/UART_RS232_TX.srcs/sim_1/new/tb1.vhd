----------------------------------------------------------------------------------
-- Company: 
-- Engineer: 
-- 
-- Create Date: 08/17/2023 04:54:46 PM
-- Design Name: 
-- Module Name: tb1 - Behavioral
-- Project Name: 
-- Target Devices: 
-- Tool Versions: 
-- Description: 
-- 
-- Dependencies: 
-- 
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
-- 
----------------------------------------------------------------------------------


library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
use IEEE.NUMERIC_STD.ALL;

-- Uncomment the following library declaration if instantiating
-- any Xilinx leaf cells in this code.
--library UNISIM;
--use UNISIM.VComponents.all;

entity tb1 is
--  Port ( );
end tb1;

architecture Behavioral of tb1 is
component TX 
    Port ( Din : in STD_LOGIC_VECTOR (7 downto 0); -- imagine the Baud Rate is : 115200;
           En : in STD_LOGIC;
           Clk : in STD_LOGIC;                     -- 100MHZ
           Dout : out STD_LOGIC;
           Busy : out STD_LOGIC);
     end component;
     signal Din : std_logic_vector(7 downto 0);
     signal En : std_logic;
     signal clk : std_logic;
     signal Dout : std_logic;
     signal Busy : std_logic;
   constant clock_period: time := 10 ns;
  signal stop_the_clock: boolean;
begin
    uut : TX port map(Din => Din,
                      En  => En,
                      Clk => Clk,
                      Dout => Dout,
                      Busy => Busy
                      );
    stimulate : process
    
    begin
        En <= '0';
        Din <= "01010111";
        wait for 100ns;
        En <= '1';
    wait;        --
    end process;
      clocking: process
  begin
    while not stop_the_clock loop
      Clk <= '0', '1' after clock_period / 2;
      wait for clock_period;
    end loop;
    wait;
  end process;

end Behavioral;
